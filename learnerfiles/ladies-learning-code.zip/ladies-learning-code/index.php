<?php get_header(); ?>
<div class="left">

			<?php get_template_part( 'loop', 'index' );	?>

</div> <!--/left-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>